package dev.sitex.gui;

import dev.sitex.Theme;
import net.minecraft.client.gui.DrawContext;

/** Small helpers that draw translucent "glass" shapes using only DrawContext.fill. */
public final class Glass {
    private Glass() {}

    /** Filled rounded rectangle. */
    public static void rounded(DrawContext c, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < r; i++) {
            int dy = r - i;
            int inset = r - (int) Math.round(Math.sqrt((double) r * r - (double) dy * dy));
            c.fill(x + inset, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, color);
        }
        c.fill(x, y + r, x + w, y + h - r, color);
    }

    /** Glass panel: dark translucent body, soft top highlight, light border. */
    public static void panel(DrawContext c, int x, int y, int w, int h, int r) {
        rounded(c, x - 1, y - 1, w + 2, h + 2, r + 1, Theme.GLASS_BORDER);
        rounded(c, x, y, w, h, r, 0xFF0B0B0D); // solid base so the border reads as a thin line
        rounded(c, x, y, w, h, r, Theme.GLASS_BODY);
        c.fillGradient(x + r, y + 1, x + w - r, y + Math.max(2, h / 2), Theme.GLASS_HIGH, 0x00FFFFFF);
    }

    public static boolean hit(int mx, int my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }
}
