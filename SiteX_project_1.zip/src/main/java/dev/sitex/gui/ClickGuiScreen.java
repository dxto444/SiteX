package dev.sitex.gui;

import dev.sitex.SiteXClient;
import dev.sitex.Theme;
import dev.sitex.module.Module;
import dev.sitex.module.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Glass-style click GUI.
 *
 * Mouse input is polled from GLFW inside render() (using the GUI-space mouse position that
 * render() receives) so this screen does not depend on the mouse-event method signatures,
 * which changed between Minecraft versions.
 */
public class ClickGuiScreen extends Screen {
    private static final int PANEL_W = 230;
    private static final int HEADER_H = 26;
    private static final int ROW_H = 20;
    private static final int SLIDER_H = 18;

    private boolean wasDown;
    private Setting dragging;

    public ClickGuiScreen() { super(Text.literal("SiteX")); }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta); // vanilla blurred background = the "glass" backdrop

        long win = client.getWindow().getHandle();
        boolean down = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean clicked = down && !wasDown;
        wasDown = down;
        if (!down) dragging = null;

        var modules = SiteXClient.modules().all;
        int total = HEADER_H + 6;
        for (Module m : modules) total += ROW_H + m.settings.size() * SLIDER_H;
        total += 8;

        int x = (width - PANEL_W) / 2;
        int y = Math.max(8, (height - total) / 2);

        Glass.panel(ctx, x, y, PANEL_W, total, 8);

        // Header
        ctx.drawTextWithShadow(textRenderer, "SiteX", x + 12, y + 9, Theme.ACCENT);
        String sub = "visuals";
        ctx.drawTextWithShadow(textRenderer, sub, x + PANEL_W - 12 - textRenderer.getWidth(sub), y + 9, Theme.TEXT_DIM);
        ctx.fill(x + 10, y + HEADER_H - 2, x + PANEL_W - 10, y + HEADER_H - 1, Theme.ACCENT_SOFT);

        int cy = y + HEADER_H + 4;
        for (Module m : modules) {
            boolean hover = Glass.hit(mx, my, x + 6, cy, PANEL_W - 12, ROW_H);
            if (hover) Glass.rounded(ctx, x + 6, cy, PANEL_W - 12, ROW_H, 4, 0x18FFFFFF);
            if (hover && clicked) m.toggle();

            ctx.drawTextWithShadow(textRenderer, m.name, x + 14, cy + 6,
                    m.isEnabled() ? Theme.TEXT : Theme.TEXT_DIM);

            // Toggle pill
            int pw = 24, ph = 10, px = x + PANEL_W - 14 - pw, py = cy + 5;
            Glass.rounded(ctx, px, py, pw, ph, 5, m.isEnabled() ? Theme.ACCENT_SOFT : Theme.OFF_PILL);
            int kx = m.isEnabled() ? px + pw - ph : px;
            Glass.rounded(ctx, kx + 1, py + 1, ph - 2, ph - 2, 4, m.isEnabled() ? Theme.ACCENT : 0xFFCCCCCC);
            cy += ROW_H;

            for (Setting s : m.settings) {
                int sx = x + 14, sw = PANEL_W - 28, sy = cy + 6;
                ctx.drawTextWithShadow(textRenderer, s.name, sx, cy + 1, Theme.TEXT_DIM);
                String val = String.format("%.1f", s.get());
                ctx.drawTextWithShadow(textRenderer, val, sx + sw - textRenderer.getWidth(val), cy + 1, Theme.TEXT_DIM);
                int ty = sy + 8;
                Glass.rounded(ctx, sx, ty, sw, 4, 2, Theme.OFF_PILL);
                double t = (s.get() - s.min) / (s.max - s.min);
                int fw = Math.max(4, (int) (sw * t));
                Glass.rounded(ctx, sx, ty, fw, 4, 2, Theme.ACCENT);
                Glass.rounded(ctx, sx + fw - 3, ty - 2, 6, 8, 3, 0xFFFFFFFF);

                if (clicked && Glass.hit(mx, my, sx - 2, ty - 4, sw + 4, 12)) dragging = s;
                if (dragging == s) {
                    double nt = Math.max(0, Math.min(1, (mx - sx) / (double) sw));
                    s.set(s.min + nt * (s.max - s.min));
                }
                cy += SLIDER_H;
            }
        }
    }
}
