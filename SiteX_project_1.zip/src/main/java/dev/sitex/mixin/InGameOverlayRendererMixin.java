package dev.sitex.mixin;

import dev.sitex.SiteXClient;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererMixin {
    @Inject(method = "renderFireOverlay", at = @At("HEAD"), cancellable = true)
    private static void sitex$noFire(CallbackInfo ci) {
        if (SiteXClient.modules() != null && SiteXClient.modules().noFire.isEnabled()) ci.cancel();
    }
}
