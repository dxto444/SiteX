package dev.sitex.mixin;

import dev.sitex.SiteXClient;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void sitex$fov(CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(SiteXClient.adjustFov(cir.getReturnValue()));
    }
}
