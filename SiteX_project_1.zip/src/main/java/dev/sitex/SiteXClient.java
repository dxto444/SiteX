package dev.sitex;

import dev.sitex.gui.ClickGuiScreen;
import dev.sitex.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public class SiteXClient implements ClientModInitializer {
    private static ModuleManager modules;
    private boolean menuKeyWasDown;

    public static ModuleManager modules() { return modules; }

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        // Sensible defaults: show the watermark and FPS counter.
        modules.watermark.setEnabled(true);
        modules.fps.setEnabled(true);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            modules.tick();
            pollMenuKey(mc);
        });
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options.hudHidden) return;
            modules.hud(ctx);
        });
    }

    /** Right Shift opens the menu (polled directly so no keybinding API is needed). */
    private void pollMenuKey(MinecraftClient mc) {
        boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (down && !menuKeyWasDown && mc.currentScreen == null) {
            mc.setScreen(new ClickGuiScreen());
        }
        menuKeyWasDown = down;
    }

    /** Called from GameRendererMixin. */
    public static float adjustFov(float fov) {
        if (modules == null) return fov;
        if (modules.customFov.isEnabled()) fov = (float) modules.customFov.fov.get();
        if (modules.zoom.isZooming()) fov /= (float) modules.zoom.factor.get();
        return fov;
    }
}
