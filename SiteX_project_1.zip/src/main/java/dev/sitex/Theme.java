package dev.sitex;

/** SiteX colour palette. All colours are ARGB. */
public final class Theme {
    private Theme() {}

    public static final int ACCENT       = 0xFFFFD43B; // main yellow
    public static final int ACCENT_SOFT  = 0x55FFD43B;
    public static final int ACCENT_DARK  = 0xFFB8920A;
    public static final int GLASS_BODY   = 0x66101012;
    public static final int GLASS_HIGH   = 0x28FFFFFF;
    public static final int GLASS_BORDER = 0x40FFFFFF;
    public static final int TEXT         = 0xFFF2F2F2;
    public static final int TEXT_DIM     = 0xFF9A9AA0;
    public static final int OFF_PILL     = 0x55FFFFFF;
}
