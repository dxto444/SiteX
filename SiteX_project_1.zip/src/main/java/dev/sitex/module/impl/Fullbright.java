package dev.sitex.module.impl;

import dev.sitex.mixin.SimpleOptionAccessor;
import dev.sitex.module.Module;

public class Fullbright extends Module {
    private Double previous;

    public Fullbright() { super("Fullbright", "Maximum brightness everywhere."); }

    @SuppressWarnings("unchecked")
    private SimpleOptionAccessor<Double> gamma() {
        return (SimpleOptionAccessor<Double>) (Object) mc.options.getGamma();
    }

    @Override public void onEnable() {
        previous = mc.options.getGamma().getValue();
        gamma().sitex$setValue(16.0);
    }

    @Override public void onDisable() {
        gamma().sitex$setValue(previous != null ? previous : 1.0);
    }

    @Override public void onTick() {
        // Keep it applied in case the options screen reset it.
        if (mc.options.getGamma().getValue() < 16.0) gamma().sitex$setValue(16.0);
    }
}
