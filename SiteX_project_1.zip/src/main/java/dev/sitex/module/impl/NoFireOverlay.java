package dev.sitex.module.impl;

import dev.sitex.module.Module;

public class NoFireOverlay extends Module {
    public NoFireOverlay() { super("No Fire Overlay", "Hides the fire effect on your screen."); }
}
