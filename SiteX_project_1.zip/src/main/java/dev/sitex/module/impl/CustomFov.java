package dev.sitex.module.impl;

import dev.sitex.module.Module;
import dev.sitex.module.Setting;

public class CustomFov extends Module {
    public final Setting fov = add(new Setting("FOV", 30, 140, 100));

    public CustomFov() { super("Custom FOV", "Set your field of view beyond the vanilla limit."); }
}
