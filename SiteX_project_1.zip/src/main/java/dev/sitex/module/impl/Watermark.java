package dev.sitex.module.impl;

import dev.sitex.Theme;
import dev.sitex.gui.Glass;
import dev.sitex.module.Module;
import net.minecraft.client.gui.DrawContext;

public class Watermark extends Module {
    public Watermark() { super("Watermark", "Shows the SiteX tag on screen."); }

    @Override public void onHud(DrawContext ctx) {
        int w = mc.textRenderer.getWidth("SiteX") + 16;
        Glass.panel(ctx, 6, 6, w, 18, 4);
        ctx.drawTextWithShadow(mc.textRenderer, "SiteX", 14, 11, Theme.ACCENT);
    }
}
