package dev.sitex.module.impl;

import dev.sitex.Theme;
import dev.sitex.gui.Glass;
import dev.sitex.module.Module;
import net.minecraft.client.gui.DrawContext;

public class CoordsHud extends Module {
    public CoordsHud() { super("Coordinates", "Shows your XYZ position."); }

    @Override public void onHud(DrawContext ctx) {
        if (mc.player == null) return;
        String s = String.format("XYZ  %.0f  %.0f  %.0f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
        int w = mc.textRenderer.getWidth(s) + 16;
        Glass.panel(ctx, 6, 50, w, 18, 4);
        ctx.drawTextWithShadow(mc.textRenderer, s, 14, 55, Theme.TEXT);
    }
}
