package dev.sitex.module.impl;

import dev.sitex.module.Module;
import dev.sitex.module.Setting;
import org.lwjgl.glfw.GLFW;

public class Zoom extends Module {
    public final Setting factor = add(new Setting("Zoom factor", 1.5, 10.0, 4.0));

    public Zoom() { super("Zoom", "Hold C to zoom in."); }

    public boolean isZooming() {
        if (!isEnabled() || mc.currentScreen != null) return false;
        return GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_C) == GLFW.GLFW_PRESS;
    }
}
