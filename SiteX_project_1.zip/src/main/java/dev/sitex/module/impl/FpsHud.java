package dev.sitex.module.impl;

import dev.sitex.Theme;
import dev.sitex.gui.Glass;
import dev.sitex.module.Module;
import net.minecraft.client.gui.DrawContext;

public class FpsHud extends Module {
    public FpsHud() { super("FPS", "Shows your frame rate."); }

    @Override public void onHud(DrawContext ctx) {
        String s = mc.getCurrentFps() + " FPS";
        int w = mc.textRenderer.getWidth(s) + 16;
        Glass.panel(ctx, 6, 28, w, 18, 4);
        ctx.drawTextWithShadow(mc.textRenderer, s, 14, 33, Theme.TEXT);
    }
}
