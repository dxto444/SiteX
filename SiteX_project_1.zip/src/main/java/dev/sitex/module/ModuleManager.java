package dev.sitex.module;

import dev.sitex.module.impl.*;

import java.util.List;

public final class ModuleManager {
    public final Fullbright fullbright = new Fullbright();
    public final Zoom zoom = new Zoom();
    public final CustomFov customFov = new CustomFov();
    public final NoFireOverlay noFire = new NoFireOverlay();
    public final Watermark watermark = new Watermark();
    public final FpsHud fps = new FpsHud();
    public final CoordsHud coords = new CoordsHud();

    public final List<Module> all = List.of(
            fullbright, zoom, customFov, noFire, watermark, fps, coords);

    public void tick() { for (Module m : all) if (m.isEnabled()) m.onTick(); }

    public void hud(net.minecraft.client.gui.DrawContext ctx) {
        for (Module m : all) if (m.isEnabled()) m.onHud(ctx);
    }
}
