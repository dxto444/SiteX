package dev.sitex.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String description;
    public final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name, String description) {
        this.name = name; this.description = description;
    }

    public boolean isEnabled() { return enabled; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean on) {
        if (on == enabled) return;
        enabled = on;
        if (on) onEnable(); else onDisable();
    }

    protected Setting add(Setting s) { settings.add(s); return s; }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    /** Called every frame for HUD-type modules while enabled. */
    public void onHud(DrawContext ctx) {}
}
