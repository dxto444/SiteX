package dev.sitex.module;

public class Setting {
    public final String name;
    public final double min, max;
    private double value;

    public Setting(String name, double min, double max, double value) {
        this.name = name; this.min = min; this.max = max; this.value = value;
    }

    public double get() { return value; }
    public void set(double v) { value = Math.max(min, Math.min(max, v)); }
}
