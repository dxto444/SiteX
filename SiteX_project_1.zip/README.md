# SiteX (Fabric, Minecraft 1.21.11)

Original, visuals-only client mod with a yellow glass GUI.

Controls: **Right Shift** opens the menu. **C** (hold) zooms when Zoom is enabled.

Modules: Fullbright, Zoom, Custom FOV, No Fire Overlay, Watermark, FPS, Coordinates.

## Build the jar (pick one)

### A) GitHub (no local setup)
1. Create a GitHub repo, upload this whole folder, push.
2. Open the Actions tab -> "build" -> download the **SiteX-jar** artifact.
   Use the jar that does NOT end in `-sources.jar`.

### B) Locally
1. Install JDK 21 and Gradle (or generate a wrapper with `gradle wrapper`).
2. Run `gradle build`. The jar is in `build/libs/SiteX-1.0.0.jar`.

## Versions
Pinned in `gradle.properties`: Yarn 1.21.11+build.6, Loader 0.20.1, Loom 1.19-SNAPSHOT, Fabric API 0.141.6+1.21.11.

## Install
Drop the jar in `.minecraft/mods` next to Fabric Loader and Fabric API for 1.21.11.

## Untested
This code was written without being able to compile or run it. If the build fails,
the most likely spots are the mixin targets (`GameRenderer.getFov`,
`InGameOverlayRenderer.renderFireOverlay`, `SimpleOption.value`) or the
`HudRenderCallback` import. Paste the compiler error and I will fix it.
